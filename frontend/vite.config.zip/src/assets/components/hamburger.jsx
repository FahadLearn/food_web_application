function Burger() {
  return (
    <>
      <div>
        <a
          href="#"
          className="flex flex-col gap-1 w-[22px] absolute top-[0px] "
        >
          <div className="border-2 border-black"></div>
          <div className="border-2 border-black"></div>
          <div className="border-2 border-black"></div>
        </a>
      </div>
    </>
  );
}
export default Burger;
